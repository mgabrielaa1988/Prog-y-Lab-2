﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data.SqlClient;
using System.Xml;
using System.Xml.Serialization;
using System.Data;

namespace ConsoleApp1
{
    public class Televisor
    {
        int codigo;
        string marca;
        float precio;
        int pulgadas;
        string pais;

        public Televisor(int codigo, string marca, float precio, int pulgadas, string pais)
        {
            this.codigo = codigo;
            this.marca = marca;
            this.precio = precio;
            this.pulgadas = pulgadas;
            this.pais = pais;
        }

        public bool Insertar()
        {
            bool retorno = false;
            SqlConnection connection = new SqlConnection(Properties.Settings.Default.Conexion);
            SqlCommand command = new SqlCommand();
            command.CommandText = "INSERT INTO Televisores values(codigo,marca,precio,pulgadas,pais)";
            command.CommandType = System.Data.CommandType.Text;
            command.Connection = connection;
            
            try
            {
                connection.Open();
                command.ExecuteNonQuery();
                retorno = true;
            }
            catch(Exception e)
            {

            }
            return retorno;
        }
    }
}
