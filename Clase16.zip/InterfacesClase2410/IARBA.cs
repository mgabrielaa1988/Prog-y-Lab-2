﻿using System;
using System.Collections.Generic;
using System.Text;

namespace InterfacesClase2410
{
    interface IARBA
    {
        double CalcularImpuesto();
    }
}
