﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Xml;
using System.Xml.Serialization;
using System.IO;

namespace Entidades
{
    [Serializable]
    public class Manzana : Fruta, ISerializar, IDeserializar
    {
        protected string _provinciaOrigen;

        public override bool TieneCarozo
        {
            get
            {
                return true;
            }
        }

        public string Nombre
        {
            get
            {
                return "Manzana";
            }
        }

        public Manzana( string color, double peso,string origen) : base(peso, color)
        {
            this._provinciaOrigen = origen;
        }

        protected override string FrutaToString()
        {
            StringBuilder sb = new StringBuilder();
            sb.AppendFormat("{0}\n{1}\tOrigen: {2}\n", this.Nombre, base.FrutaToString(), this._provinciaOrigen);
            return sb.ToString();
        }

        public override string ToString()
        {
            return this.FrutaToString();
        }

        public string RutaArchivo
        {
            get
            {
                return AppDomain.CurrentDomain.BaseDirectory;
            }
            set
            {
                this.RutaArchivo = value;
            }
        }

        public bool Xml(string nombre, out Fruta fruta)
        {
            fruta = null;
            try
            {
                TextWriter escritor = new StreamWriter(this.RutaArchivo + "Archivo.xml");
                XmlSerializer serializador = new XmlSerializer(typeof(Manzana));
                serializador.Serialize(escritor, this);
                escritor.Close();
            }
            catch (Exception e)
            {
                Console.WriteLine(e.Message);
                return false;
            }
            return true;
        }

        public bool Xml(string nombre)
        {
            try
            {
                TextWriter escritor = new StreamWriter(this.RutaArchivo + @"\" + nombre);
                XmlSerializer serializador = new XmlSerializer(typeof(Manzana));
                serializador.Serialize(escritor, this);
                escritor.Close();
            }
            catch (Exception e)
            {
                Console.WriteLine(e.Message);
                return false;
            }
            return true;
        }
    }
}
