﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Clase07_1109
{
    class Clase_07
    {
        static void Main(string[] args)
        {
            Console.Title = "Clase 07";

            Tempera temperaUno = new Tempera(3, ConsoleColor.Green, "Equis");
            
        }
    }
}
